const API = "http://127.0.0.1:8000"

// Register function
async function register() {
    const username = document.getElementById("username").value
    const email = document.getElementById("email").value
    const password = document.getElementById("password").value
    const message = document.getElementById("message")

    const response = await fetch(`${API}/users/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, email, password })
    })

    const data = await response.json()

    if (response.ok) {
        message.className = "success"
        message.innerText = "Account created! Redirecting..."
        setTimeout(() => window.location.href = "index.html", 1500)
    } else {
        message.className = "error"
        message.innerText = data.detail
    }
}

// Login function
async function login() {
    const email = document.getElementById("email").value
    const password = document.getElementById("password").value
    const message = document.getElementById("message")

    const formData = new URLSearchParams()
    formData.append("username", email)
    formData.append("password", password)

    const response = await fetch(`${API}/users/login`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: formData
    })

    const data = await response.json()

    if (response.ok) {
        localStorage.setItem("token", data.access_token)
        localStorage.setItem("username", email)
        message.className = "success"
        message.innerText = "Login successful! Redirecting..."
        setTimeout(() => window.location.href = "chat.html", 1500)
    } else {
        message.className = "error"
        message.innerText = data.detail
    }
}