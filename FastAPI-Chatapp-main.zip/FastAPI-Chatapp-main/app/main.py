from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import engine
from . import models
from .routers import users,chat

models.Base.metadata.create_all(bind=engine)

app=FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(users.router)
app.include_router(chat.router)

@app.get("/")
def root():
    return {"Message":"Chat APP running"}

@app.get("/Hello{name}")
def hello(name:str):
    return{"Message":f"Hello {name} "}