import bcrypt
from fastapi import APIRouter , Depends ,HTTPException
from sqlalchemy.orm import Session
from . . import models, schemas
from . .database import get_db
from passlib.context import CryptContext
from ..oauth2 import create_access_token, get_current_user
from fastapi.security import OAuth2PasswordRequestForm

router = APIRouter(prefix="/users", tags=["Users"])

pwd_context= CryptContext(schemes=["bcrypt"],deprecated="auto")


@router.post("/login", response_model=schemas.Token)
def login(user_credentials: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    
    # User check karo
    db_user = db.query(models.User).filter(models.User.email == user_credentials.username).first()
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")

    # Password check karo
    if not bcrypt.checkpw(user_credentials.password.encode('utf-8'), db_user.password.encode('utf-8')):
        raise HTTPException(status_code=403, detail="Invalid credentials")

    # Token banao
    access_token = create_access_token(data={"sub": db_user.email})

    return {"access_token": access_token, "token_type": "bearer"}

@router.post("/register",response_model=schemas.UserResponse)
def register(user: schemas.UserCreate, db: Session=Depends(get_db)):
    existing=db.query(models.User).filter(models.User.email == user.email).first()
    if existing:
        raise HTTPException(status_code=400,detail="Email already Registered")
    
    hashed_password=pwd_context.hash(user.password)
    
    new_user=models.User(
        username=user.username,
        email=user.email,
        password=hashed_password
    )
    
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    return new_user
    
    
@router.get("/me", response_model=schemas.UserResponse)
def get_me(current_user: models.User = Depends(get_current_user)):
    return current_user